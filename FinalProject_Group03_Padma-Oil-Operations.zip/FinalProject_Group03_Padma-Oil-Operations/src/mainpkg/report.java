/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

/**
 *
 * @author ragib
 */
public class report {
    protected int empId;
    protected String subject;
    protected String message;
    
    public report()
    {
        
    }
    public report(int i, String sub, String m)
    {
        empId=i;
        subject=sub;
        message=m;
    }
    
     public void setSubject(String sub)
            {
                subject=sub;
            }
    public String getSubject()
            {
                return subject;
            }
    public void setEmpID(int id)
            {
                empId=id;
            }
    public int getEmpID()
            {
                return empId;
            }
    public void setMessage(String m)
            {
                message=m;
            }
    public String getMessage()
            {
                return message;
            }
}
