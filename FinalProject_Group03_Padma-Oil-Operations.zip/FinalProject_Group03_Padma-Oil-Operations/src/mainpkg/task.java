/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.time.LocalDate;
import java.io.Serializable;

/**
 *
 * @author ragib
 */
public class task implements Serializable{
    protected String tName;
    protected int taskId;
    protected LocalDate sDate;
    protected LocalDate eDate;
    
    
    public task()
    {
        
    }
    public task(String n, int i, LocalDate s, LocalDate e)
    {
        tName=n;
        taskId=i;
        sDate=s;
        eDate=e;
    }
    
    
    public void setTaskName(String tn)
            {
                tName=tn;
            }
    public String getTaskName()
            {
                return tName;
            }
    public void setTaskID(int tid)
            {
                taskId=tid;
            }
    public int getTaskID()
            {
                return taskId;
            }
    public void setSDate(LocalDate s)
            {
                sDate=s;
            }
    public LocalDate getSDate()
            {
                return sDate;
            }
    public void setEDate(LocalDate e)
            {
                eDate=e;
            }
    public LocalDate getEDate()
            {
                return eDate;
            }
    
}
