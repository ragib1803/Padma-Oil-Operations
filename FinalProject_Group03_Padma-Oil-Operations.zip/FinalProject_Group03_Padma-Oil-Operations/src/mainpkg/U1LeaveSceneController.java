/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U1LeaveSceneController implements Initializable {

    @FXML
    private TextField leaveIdField;
    @FXML
    private TextField leaveReasonField;
    @FXML
    private TextArea leaveMessageArea;
    @FXML
    private DatePicker leaveDate;
    @FXML
    private DatePicker returnDate;
    @FXML
    private Label notify;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void submitLeave(ActionEvent event) {
        int id=Integer.parseInt(leaveIdField.getText());
        String r=leaveReasonField.getText();
        String m=leaveMessageArea.getText();
        LocalDate s=leaveDate.getValue();
        LocalDate e=returnDate.getValue();
        
        leaveApplication l = new leaveApplication(r,id,s,e,m);
        
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("leaveApplicationObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(l);
            
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
                notify.setText("Leave Application Submitted");
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }

    @FXML
    private void u1Home(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U1DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }
    
}
