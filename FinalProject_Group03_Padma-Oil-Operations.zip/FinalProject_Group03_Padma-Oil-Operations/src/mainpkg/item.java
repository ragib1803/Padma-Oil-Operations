/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.Serializable;

/**
 *
 * @author ragib
 */
public class item implements Serializable{
    protected String iName;
    protected int itemId;
    
    public item()
    {
        
    }
    public item(String n, int i)
    {
        iName=n;
        itemId=i;
    }
    
    public void setItemID(int id)
            {
                itemId=id;
            }
    public int getItemID()
            {
                return itemId;
            }
    public void setItemName(String n)
            {
                iName=n;
            }
    public String getItemName()
            {
                return iName;
            }

    
}
