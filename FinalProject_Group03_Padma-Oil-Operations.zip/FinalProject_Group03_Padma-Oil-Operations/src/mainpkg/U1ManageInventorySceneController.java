/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U1ManageInventorySceneController implements Initializable {

    @FXML
    private TextField itemIdfield;
    @FXML
    private TextField itemQuantityfield;
    @FXML
    private TextField itemNameField;
    @FXML
    private TextField itemPriceField;
    @FXML
    private TableView<inventoryItem> inventoryTable;
    @FXML
    private TableColumn<inventoryItem, String> updateNameCol;
    @FXML
    private TableColumn<inventoryItem, Integer> updateIdCol;
    @FXML
    private TableColumn<inventoryItem, Integer> updateQuantityCol;
    @FXML
    private TableColumn<inventoryItem, Integer> updatePriceCol;
    @FXML
    private TextField reqQuantityField;
    @FXML
    private TextField reqNameField;
    @FXML
    private TextField reqPriceField;
    @FXML
    private TableView<?> requestItemTable;
    @FXML
    private TableColumn<?, ?> reqNameCol;
    @FXML
    private TableColumn<?, ?> quantityReqCol;
    @FXML
    private TableColumn<?, ?> reqPriceCol;
    @FXML
    private TableColumn<?, ?> totalPriceCol;
    @FXML
    private Label notify;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        updateIdCol.setCellValueFactory(new PropertyValueFactory<>("itemId"));
        updateNameCol.setCellValueFactory(new PropertyValueFactory<>("iName"));
        updateQuantityCol.setCellValueFactory(new PropertyValueFactory<>("qty"));
        updatePriceCol.setCellValueFactory(new PropertyValueFactory<>("cost"));
        
        ArrayList<inventoryItem> invArr = new ArrayList<>();
        ObjectInputStream ois = null;
        try {
            inventoryItem e;
            ois = new ObjectInputStream(new FileInputStream("inventoryItemObjects.bin"));
            while (true) {
                e = (inventoryItem) ois.readObject();
                invArr.add(e);
                }
            }  catch (Exception ex) {
                Logger.getLogger(U1ManageInventorySceneController.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
            } catch (IOException ex) {
                Logger.getLogger(U1ManageInventorySceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    ObservableList<inventoryItem> oinvItemList = FXCollections.observableArrayList(invArr);
    inventoryTable.setItems(oinvItemList);
        
    }    

    @FXML
    private void updateInventoryList(ActionEvent event) {
        
    int id=Integer.parseInt(itemIdfield.getText());
    int q=Integer.parseInt(itemQuantityfield.getText());
    String n = itemNameField.getText();
    int p=Integer.parseInt(itemPriceField.getText());
        
        inventoryItem inv = new inventoryItem(id,n,p,q);
        
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("inventoryItemObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(inv);
            notify.setText("Inventory Updated. \nRefresh to view.");
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }

    @FXML
    private void requestItem(ActionEvent event) {
    }

    @FXML
    private void u1Home(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U1DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();    
    }
    
}
