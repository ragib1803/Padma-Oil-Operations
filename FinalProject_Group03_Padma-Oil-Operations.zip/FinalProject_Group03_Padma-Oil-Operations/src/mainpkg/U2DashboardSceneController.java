/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U2DashboardSceneController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void manageUsers(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2ManageUsersScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show(); 
    }

    @FXML
    private void applyLeave(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2LeaveScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void reqHardware(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2HardwareScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void complainHR(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2ComplainScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void logoutOnClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U0LoginScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void bugReport(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2BugReportScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void updateProduct(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2UpdateDetailScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }
    
}
