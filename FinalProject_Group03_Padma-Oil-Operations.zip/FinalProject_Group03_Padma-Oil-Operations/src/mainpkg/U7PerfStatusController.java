/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class U7PerfStatusController implements Initializable {

    @FXML
    private AnchorPane ap77;
    @FXML
    private Label pf71;
    @FXML
    private TableView<?> box77;
    @FXML
    private TableColumn<?, ?> n77;
    @FXML
    private TableColumn<?, ?> id77;
    @FXML
    private TableColumn<?, ?> s77;
    @FXML
    private Label nm79;
    @FXML
    private Label id78;
    @FXML
    private Label st77;
    @FXML
    private TextField name78;
    @FXML
    private TextField id79;
    @FXML
    private TextField st78;
    @FXML
    private Button add77;
    @FXML
    private Button dlt77;
    @FXML
    private Button hm77;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addeqperformance(ActionEvent event) {
    }

    @FXML
    private void deleteqperformance(ActionEvent event) {
    }

    @FXML
    private void gotohomepage(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7Dashboard.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }
    }
    

