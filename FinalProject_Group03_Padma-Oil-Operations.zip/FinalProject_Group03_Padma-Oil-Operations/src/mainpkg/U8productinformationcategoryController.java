/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class U8productinformationcategoryController implements Initializable {

    @FXML
    private Button prdctl;
    @FXML
    private Button prdctproposal;
    @FXML
    private Button pg;
    @FXML
    private Button sp;
    @FXML
    private Button home81;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void showproductlist(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8ProductList.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void proposeforproducts(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8Productproposal.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void gotoproductgoalpage(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8productgoals.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void showsoldproductslist(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8soldproducts.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void gotohomepage(ActionEvent event) throws IOException {
        
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8Dashboard.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }
    
}
