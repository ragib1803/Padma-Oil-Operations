/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.time.LocalDate;

/**
 *
 * @author ragib
 */
public class warehouseSupervisor extends employee{
    protected int warehouse;
    
    public warehouseSupervisor()
    {
        
    }
    public warehouseSupervisor(int id, String pass, LocalDate joinD,String des, int sal, int w)
    {
        empId=id;
        password=pass;
        doj=joinD;
        designation=des;
        salary=sal;
        warehouse=w;
    }
    public void setWarehouseNo(int w)
            {
                warehouse=w;
            }
    public int getWarehouseNo()
            {
                return warehouse;
            }
    
}
