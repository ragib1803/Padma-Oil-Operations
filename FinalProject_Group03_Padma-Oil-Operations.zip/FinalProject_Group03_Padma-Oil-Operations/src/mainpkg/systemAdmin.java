/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.time.LocalDate;

/**
 *
 * @author ragib
 */
public class systemAdmin extends employee{
    protected int systemPass;
    
    public systemAdmin()
    {
        
    }
    public systemAdmin(int id, String pass, LocalDate joinD,String des, int sal, int p)
    {
        empId=id;
        password=pass;
        doj=joinD;
        designation=des;
        salary=sal;
        systemPass=p;
    }
    public void setSystemPass(int s)
            {
                systemPass=s;
            }
    public int getSystemPass()
            {
                return systemPass;
            }
    
}
