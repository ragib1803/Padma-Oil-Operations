/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;
import java.time.LocalDate;
/**
 *
 * @author Asif
 */
public class Order {
    private int orderid;
    private int quantity;
  
private  LocalDate orderDate ;
private  String orderAddress ;
 private String distributionChannelType;
 public Order(){
     
 }

    
}
