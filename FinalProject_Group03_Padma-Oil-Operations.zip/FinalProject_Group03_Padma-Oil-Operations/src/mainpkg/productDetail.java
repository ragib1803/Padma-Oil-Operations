/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

/**
 *
 * @author ragib
 */
public class productDetail extends item{
   
    protected int price;
    protected int unit;
    
    public productDetail()
    {
        
    }
    public productDetail(int p, int u)
    {
        price=p;
        unit=u;
    }
    public void setProductPrice(int p)
            {
                price=p;
            }
    public int getProductPrice()
            {
                return price;
            }
    public void setProductUnit(int u)
            {
                unit=u;
            }
    public int getProductUnit()
            {
                return unit;
            }
}
    

