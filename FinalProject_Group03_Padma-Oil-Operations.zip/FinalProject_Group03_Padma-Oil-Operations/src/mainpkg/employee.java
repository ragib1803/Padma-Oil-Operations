/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.time.LocalDate;
import java.io.Serializable;
/**
 *
 * @author ragib
 */
public class employee  extends person implements Serializable{
    protected int empId;
    protected String password;
    protected LocalDate doj;
    protected String designation;
    protected int salary;
    
    public employee()
    {
        
    }
    public employee(int id, String n, LocalDate birthD, int ph, String e, String pass, LocalDate joinD,String des, int sal)
    {
        super(n, birthD, ph, e);
        empId=id;
        password=pass;
        doj=joinD;
        designation=des;
        salary=sal;
        
        
        
    }
    
    
    public int getEmpId()
            {
                return empId;
            }
    public String getPassword()
            {
                return password;
            }
    public void setEmpId(int id)
            {
                empId=id;
            }
    public void setPassword(String pw)
            {
                password=pw;
            }
    public String getDesignation()
            {
                return designation;
            }
    public void setDesignation(String d)
            {
                designation=d;
            }
    public int getSalary()
            {
                return salary;
            }
    public void setSalary(int s)
            {
                salary=s;
            }
    public LocalDate getDoj()
            {
                return doj;
            }
    public void setDoj(LocalDate d)
            {
               doj=d;
            }
}
