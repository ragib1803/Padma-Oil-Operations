/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;
import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author ragib
 */
public class person implements Serializable{
    protected String name;
    protected LocalDate dob;
    protected int phone;
    protected String email;
    
    public person()
    {
        
    }
    
    public person(String n, LocalDate d, int p, String e )
    {
        name=n;
        dob=d;
        phone=p;
        email=e;
    }
    
    public void setName(String n)
    {
        name=n;
    }
    public void setDob(LocalDate n)
    {
        dob=n;
    }
    public void setPhone(int n)
    {
        phone=n;
    }
    public void setEmail(String n)
    {
        email=n;
    }
    public String getName()
    {
        return name;
    }
    public LocalDate getDob()
    {
        return dob;
    }
    public int getPhone()
    {
        return phone;
    }
    public String getEmail()
    {
        return email;
    }
    
}