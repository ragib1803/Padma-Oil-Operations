/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class U8reportController implements Initializable {

    @FXML
    private AnchorPane ap16;
    @FXML
    private Label psr;
    @FXML
    private Label product26;
    @FXML
    private Label productid28;
    @FXML
    private Label feedback22;
    @FXML
    private TextField product27;
    @FXML
    private TextField productid29;
    @FXML
    private TextField feedback23;
    @FXML
    private Button home25;
    @FXML
    private TextArea showreport1;
    @FXML
    private Button showrep2;
    @FXML
    private Button save99;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    @FXML
    private void gotohomepage(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8Dashboard.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void showrep(ActionEvent event) {
    }

    @FXML
    private void Savethereport(ActionEvent event) {
    }
    }

    
    

