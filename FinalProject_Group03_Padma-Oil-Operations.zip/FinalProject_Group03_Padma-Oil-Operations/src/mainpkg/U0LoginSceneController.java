/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author ragib
 */
public class U0LoginSceneController implements Initializable {
    String verify;
    //private Label label;
    @FXML
    private TextField idTextField;
    @FXML
    private TextField pwTextField;
    @FXML
    private ComboBox<String> empCombobox;
    
    private employee emp = new employee();
    
    @FXML
    private Label notify;
    
    int v=0;
    void verify()
            
        {
            ArrayList<employee> empArr = new ArrayList<>();
            ObjectInputStream ois = null;
            try {
                employee e;
                ois = new ObjectInputStream(new FileInputStream("userObjects.bin"));
                while (true) {
                    e = (employee) ois.readObject();
                    empArr.add(e);
                    }
                }  catch (Exception ex) {
                    Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
                } finally {
                    try {
                        if (ois != null) {
                            ois.close();
                        }
                } catch (IOException ex) {
                    Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            for(employee w: empArr)
            {
                if(Integer.parseInt(idTextField.getText())== w.getEmpId() && pwTextField.getText()==w.getPassword())
                {
                    v=1;
                }
            }
            

            
            
        }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        empCombobox.getItems().addAll("Warehouse Supervisor", "System Administrator", "HR Manager", "Finance Head", "Distribution Officer", "Account Officer", "Maintenance Engineer", "Sales Engineer");
        
    }    

    
    @FXML
    private void loginOnClick(ActionEvent event) throws IOException {
        
      // if(v==1)
      // {
            if(empCombobox.getValue()=="Warehouse Supervisor" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U1DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Warehouse Supervisor");
        }
        else if(empCombobox.getValue()=="System Administrator" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil System Administrator");
        }
        else if(empCombobox.getValue()=="HR Manager" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U3Dashboardscene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil HR Manager");
        }
        else if(empCombobox.getValue()=="Finance Head" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U4Dashboardscene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Finance Head");
        }
        else if(empCombobox.getValue()=="Distribution Officer" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Distribution Officer");
        }
        else if(empCombobox.getValue()=="Account Officer" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U6Dashboard.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Account Officer");
        }
        else if(empCombobox.getValue()=="Maintenance Engineer")//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7Dashboard.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Maintenance Engineer");
        }
        else if(empCombobox.getValue()=="Sales Engineer" )//&& verify=="true" )
        {
            FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U8Dashboard.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Sales Engineer");
        }
      // }
      // else notify.setText("Inavlid Credentials");
        
    }
    
}
