/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class U5PricingStrategyController implements Initializable {

    @FXML
    private TableView<?> pTableView;
    @FXML
    private TableColumn<?, ?> price;
    @FXML
    private TableColumn<?, ?> unit;
    @FXML
    private TableColumn<?, ?> description;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
     private void u5Home(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }
    
}
