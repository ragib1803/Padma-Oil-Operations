/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U2ManageUsersSceneController implements Initializable {

    @FXML
    private TextField userIdField;
    @FXML
    private TextField contactField;
    @FXML
    private TextField salaryField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField pwField;
    @FXML
    private TextField userNameField;
    @FXML
    private DatePicker dobPicker;
    @FXML
    private DatePicker dojPick;
    @FXML
    private ComboBox<String> designationCombobox;
    @FXML
    private TableView<employee> employeeListDelete;
    @FXML
    private TableColumn<employee, Integer> deleteIdCol;
    @FXML
    private TableColumn<employee, String> deleteNameCol;
    @FXML
    private TextField deleteIdField;
    @FXML
    private TextField userIdFieldDel;
    @FXML
    private TextField contactFieldDel;
    @FXML
    private TextField salaryFieldDel;
    @FXML
    private TextField emailFieldDel;
    @FXML
    private TextField pwFieldDel;
    @FXML
    private TextField userNameFieldDel;
    @FXML
    private DatePicker dobPickerDel;
    @FXML
    private DatePicker dojPickDel;
    @FXML
    private ComboBox<String> designationComboboxDel;
    @FXML
    private Label notify;
    @FXML
    private CheckBox svCheckbox;
    @FXML
    private CheckBox saCheckbox;
   

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         designationCombobox.getItems().addAll("Warehouse Supervisor", "System Administrator", "HR Manager", "Finance Head", "Distribution Officer", "Account Officer", "Maintenance Engineer", "Sales Engineer");
        designationComboboxDel.getItems().addAll("Warehouse Supervisor", "System Administrator", "HR Manager", "Finance Head", "Distribution Officer", "Account Officer", "Maintenance Engineer", "Sales Engineer");
         
        ArrayList<employee> empArr = new ArrayList<>();
        ObjectInputStream ois = null;
        try {
            employee e;
            deleteIdCol.setCellValueFactory(new PropertyValueFactory<>("empId"));
            deleteNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
            ois = new ObjectInputStream(new FileInputStream("empListObjects.bin"));
            while (true) {
                e = (employee) ois.readObject();
                empArr.add(e);
            }
        }  catch (Exception ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        ObservableList<employee> oEmpList = FXCollections.observableArrayList(empArr);
        employeeListDelete.setItems(oEmpList);
    }    
    //ArrayList <employee> empList=new ArrayList();
    @FXML
    private void addUserToEmpList(ActionEvent event) {
        
        if(saCheckbox.isSelected())
        {
            employee e = new employee(Integer.parseInt(userIdField.getText()),userNameField.getText(), dobPicker.getValue(), Integer.parseInt(contactField.getText()), emailField.getText(), pwField.getText(),dojPick.getValue(), designationCombobox.getValue(), Integer.parseInt(salaryField.getText()));
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("UserObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(e);
            notify.setText("User Added.");
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        }
        
        if(svCheckbox.isSelected())
        {
                employee e = new employee(Integer.parseInt(userIdField.getText()),userNameField.getText(), dobPicker.getValue(), Integer.parseInt(contactField.getText()), emailField.getText(), pwField.getText(),dojPick.getValue(), designationCombobox.getValue(), Integer.parseInt(salaryField.getText()));
        File f1 = new File("empListObjects.bin");
        File f2 = new File("supervisedEmpObjects.bin");
        FileOutputStream fos1 = null;
        FileOutputStream fos2 = null;      
        ObjectOutputStream oos1 = null;
        ObjectOutputStream oos2 = null;

        try {
            if (f1.exists()) {
                fos1 = new FileOutputStream(f1, true);
                oos1 = new customObjectOutputStream(fos1);                
            } else {
                fos1 = new FileOutputStream(f1);
                oos1 = new ObjectOutputStream(fos1);               
            }

            if (f2.exists()) {
                fos2 = new FileOutputStream(f2, true);
                oos2 = new customObjectOutputStream(fos2);                
            } else {
                fos2 = new FileOutputStream(f2);
                oos2 = new ObjectOutputStream(fos2);               
            }

            oos1.writeObject(e);
            oos2.writeObject(e);
            notify.setText("The User Has been added");

            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (oos1 != null) oos1.close();
                    if (oos2 != null) oos2.close();
                } catch (IOException ex) {
                    Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        else 
                {
                    employee e = new employee(Integer.parseInt(userIdField.getText()),userNameField.getText(), dobPicker.getValue(), Integer.parseInt(contactField.getText()), emailField.getText(), pwField.getText(),dojPick.getValue(), designationCombobox.getValue(), Integer.parseInt(salaryField.getText()));
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("empListObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(e);
            notify.setText("The User Has been added");
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
                }
    }

    @FXML
    private void u2Home(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U2DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void deleteUser(ActionEvent event) {
        ArrayList<employee> empArr = new ArrayList<>();
        ObjectInputStream ois = null;
        try {
            employee e;
            
            ois = new ObjectInputStream(new FileInputStream("empListObjects.bin"));
            while (true) {
                e = (employee) ois.readObject();
                empArr.add(e);
            }
        }  catch (Exception ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
                ArrayList<employee> newEmpArr = new ArrayList<>();
                for(employee w: empArr)
                {
                    if(Integer.parseInt(deleteIdField.getText())!=w.getEmpId())
                    {
                        newEmpArr.add(w);
                    }
                }
                
                
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("empListObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new ObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new customObjectOutputStream(fos);               
            }
            for(employee w: newEmpArr)
                {
                    oos.writeObject(w);
                    
                }
            
            
            notify.setText("User Deleted.");
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        
        
    }

    @FXML
    private void modifyUser(ActionEvent event) {
    }
    
}
