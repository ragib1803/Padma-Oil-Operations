/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.Serializable;

/**
 *
 * @author ragib
 */
public class inventoryItem extends item implements Serializable{
    
    protected int cost;
    protected int qty;
    
    public inventoryItem()
    {
        
    }
    public inventoryItem(int id, String n, int p, int q)
    {
        iName=n;
        itemId=id;
        cost=p;
        qty=q;
    }
    public void setInvPrice(int p)
            {
                cost=p;
            }
    public int getInvPrice()
            {
                return cost;
            }
    public void setInvQty(int q)
            {
                qty=q;
            }
    public int getInvQty()
            {
                return qty;
            }
}

