/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U5DashboardSceneController implements Initializable {

    @FXML
    private Label DistrtibutionOfficer;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void loadsalesforecasting(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5SalesForecasting.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void loadlogisticsplanning(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5LogisticsPlanning.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
        
    }

    @FXML
    private void loadsupplychainmanagement(ActionEvent event)throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5Supplychainmanagement.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
        
    }

    @FXML
    private void laodinventorymanagement(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5InventoryManagement.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void loadqualitycontrol(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5QuilityControl.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void loadpricingstrategy(ActionEvent event)throws IOException {
          FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5PricingStrategy.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void loadcustomerrelationshipmanagement(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5CustomerRelationshipManagement.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void loadapplyforleave(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U5ApplyForLeave.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
        
    }

    @FXML
    private void logOUT(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U0LoginScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }
    
}
