/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U1ManageEmployeeSceneController implements Initializable {

    @FXML
    private TextField assignEmployeeTextField;
    @FXML
    private TextField taskIdTextField;
    @FXML
    private TextField taskNameTextField;
    @FXML
    private DatePicker assignDP;
    @FXML
    private DatePicker dueDP;
    @FXML
    private TextField assignTaskIdTextField;
    @FXML
    private TableView<?> assignTaskTable;
    @FXML
    private TableView<employee> empListTable;
    @FXML
    private TextArea requestDisplayArea;
    @FXML
    private TableView<?> requestTable;
    @FXML
    private TableColumn<?, ?> assignEmployeeIdCol;
    @FXML
    private TableColumn<?, ?> assignEmployeeNameCol;
    @FXML
    private TableColumn<?, ?> assignTaskIdCol;
    @FXML
    private TableColumn<?, ?> assignTaskNameCol;
    @FXML
    private TableColumn<?, ?> assignDateCol;
    @FXML
    private TableColumn<?, ?> dueDateCol;
    @FXML
    private TextField reviewIdField;
    @FXML
    private TableColumn<employee,Integer> empIdCol;
    @FXML
    private TableColumn<employee, String> empNameCol;
    @FXML
    private TableColumn<employee, Integer> salaryCol;
    @FXML
    private TableColumn<employee, Integer> phoneCol;
    @FXML
    private TableColumn<employee, String> emailCol;
    @FXML
    private TableColumn<employee, String> empPosCol;
    @FXML
    private TableColumn<?, ?> reqEmpIdCol;
    @FXML
    private TableColumn<?, ?> reqEmpNameCol;
    @FXML
    private TableColumn<?, ?> reqReqCol;
    @FXML
    private Label notify;
    @FXML
    private TextField skillField;
    @FXML
    private TextField attendanceField;
    @FXML
    private TextField behaviourField;

    private ArrayList<task> taskList = new ArrayList();
    @FXML
    private BarChart<?, ?> perfBarChart;
    @FXML
    private NumberAxis ratingAxisY;
    @FXML
    private CategoryAxis skillAxisX;
  
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        empIdCol.setCellValueFactory(new PropertyValueFactory<>("empId"));
        empNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        salaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        empPosCol.setCellValueFactory(new PropertyValueFactory<>("designation"));
        
        ArrayList<employee> empArr = new ArrayList<>();
    ObjectInputStream ois = null;
    try {
        employee e;
        ois = new ObjectInputStream(new FileInputStream("supervisedEmpObjects.bin"));
        while (true) {
            e = (employee) ois.readObject();
            empArr.add(e);
            }
        }  catch (Exception ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
        } catch (IOException ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    ObservableList<employee> oEmpList = FXCollections.observableArrayList(empArr);
    empListTable.setItems(oEmpList);
    
    }    

    @FXML
    private void createTask(ActionEvent event) {
        task t = new task(taskNameTextField.getText(),Integer.parseInt(taskIdTextField.getText()), assignDP.getValue(), dueDP.getValue());
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("AssignedTaskObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(t);

        } catch (IOException ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
                notify.setText("Task Created");
            } catch (IOException ex) {
                Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
        
    }

    @FXML
    private void assignTask(ActionEvent event) {
        
        assignedTask t = new assignedTask(taskNameTextField.getText(),Integer.parseInt(taskIdTextField.getText()), assignDP.getValue(), dueDP.getValue(), Integer.parseInt(assignEmployeeTextField.getText()));
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("AssignedTaskObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(t);
            
        } catch (IOException ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
                notify.setText("Task Assigned");
            } catch (IOException ex) {
                Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
    }

    @FXML
    private void submitPerformanceReport(ActionEvent event) {
       // performanceReport pr = new employee(Integer.parseInt(userIdField.getText()),userNameField.getText(), dobPicker.getValue(), Integer.parseInt(contactField.getText()), emailField.getText(), pwField.getText(),dojPick.getValue(), designationCombobox.getValue(), Integer.parseInt(salaryField.getText()));
        
                
    }

    @FXML
    private void viewRequest(ActionEvent event) {
    }

    @FXML
    private void u1Home(ActionEvent event) throws IOException {
                    FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U1DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();    
    }

    @FXML
    private void submitReview(ActionEvent event) {
        
        employee emp= new employee();
        
        ArrayList<employee> empArr = new ArrayList<>();
    ObjectInputStream ois = null;
    try {
        employee e;
        ois = new ObjectInputStream(new FileInputStream("supervisedEmpObjects.bin"));
        while (true) {
            e = (employee) ois.readObject();
            empArr.add(e);
            }
        }  catch (Exception ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
        } catch (IOException ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    for(employee w: empArr)
    {
        if(Integer.parseInt(reviewIdField.getText())==w.getEmpId())
        {
            emp=w;
        }
    }
    performanceReport pr = new performanceReport(Integer.parseInt(attendanceField.getText()),Integer.parseInt(skillField.getText()),Integer.parseInt(behaviourField.getText()),emp.getEmpId(), emp.getName(), emp.getDob() , emp.getPhone(), emp.getEmail(), emp.getPassword(), emp.getDoj(), emp.getDesignation(), emp.getSalary());
    
    //ObservableList<employee> oEmpList = FXCollections.observableArrayList(empArr);
    //empListTable.setItems(oEmpList);
        
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("empPerfReportObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(pr);
            notify.setText("Report Submitted.");
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(pr.getAttendance()+", "+pr.getSkill()+", "+pr.getBehaviour());
    }

    @FXML
    private void showReview(ActionEvent event) {
        
        performanceReport pr = new performanceReport();
    
    //ObservableList<employee> oEmpList = FXCollections.observableArrayList(empArr);
    //empListTable.setItems(oEmpList);
        
        ArrayList<performanceReport> prArr = new ArrayList<>();
    ObjectInputStream ois = null;
    try {
        
        ois = new ObjectInputStream(new FileInputStream("empPerfReportObjects.bin"));
        while (true) {
            pr = (performanceReport) ois.readObject();
            prArr.add(pr);
            }
        }  catch (Exception ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
        } catch (IOException ex) {
            Logger.getLogger(U1ManageEmployeeSceneController.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
    for(performanceReport p: prArr)
    {
        if(Integer.parseInt(reviewIdField.getText())== p.getEmpId())
        {
            pr=p;
            p.rateAttendance(Integer.parseInt(attendanceField.getText()));
            p.rateSkill(Integer.parseInt(skillField.getText()));
            p.rateBehaviour(Integer.parseInt(behaviourField.getText()));
            
        }
    }
    
     CategoryAxis skillAxisX = new CategoryAxis();
        skillAxisX.setLabel("Category");
        
        NumberAxis ratingAxisY = new NumberAxis();
        ratingAxisY.setLabel("Rating");
        
        BarChart<String, Number> perfBarChart = new BarChart<>(skillAxisX, ratingAxisY);
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Attendance", pr.getAttendance()));
        series.getData().add(new XYChart.Data<>("Skill", pr.getSkill()));
        series.getData().add(new XYChart.Data<>("Behaviour",pr.getBehaviour() ));
        
        perfBarChart.getData().add(series);
    }
}