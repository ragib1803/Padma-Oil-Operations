/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.time.LocalDate;

/**
 *
 * @author ragib
 */
public class leaveApplication {
    protected String reason;
    protected int empId;
    protected LocalDate sDate;
    protected LocalDate eDate;
    protected String message;
    
    public leaveApplication()
    {
        
    }
    public leaveApplication(String n, int i, LocalDate s, LocalDate e, String m)
    {
        reason=n;
        empId=i;
        sDate=s;
        eDate=e;
        message=m;
    }
    
    
    public void setReason(String r)
            {
                reason=r;
            }
    public String getReason()
            {
                return reason;
            }
    public void setEmpID(int eid)
            {
                empId=eid;
            }
    public int getEmpID()
            {
                return empId;
            }
    public void setSDate(LocalDate s)
            {
                sDate=s;
            }
    public LocalDate getSDate()
            {
                return sDate;
            }
    public void setEDate(LocalDate e)
            {
                eDate=e;
            }
    public LocalDate getEDate()
            {
                return eDate;
            }
    public void setMessage(String r)
            {
                reason=r;
            }
    public String getMessage()
            {
                return reason;
            }
    
}
