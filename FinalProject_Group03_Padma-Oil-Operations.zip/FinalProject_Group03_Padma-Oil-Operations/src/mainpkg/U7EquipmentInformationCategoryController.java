/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class U7EquipmentInformationCategoryController implements Initializable {

    @FXML
    private BorderPane box0;
    @FXML
    private Button eh;
    @FXML
    private Button avep0;
    @FXML
    private Button cre;
    @FXML
    private Button ep71;
    @FXML
    private Button raeq1;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void showequipmentperformance(ActionEvent event) throws IOException {
           FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7PerfStatus.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");  
    }

    @FXML
    private void equipmenthandlingprocedure(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7equipmenthandling.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void showavailableequipments(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7equipmentavailability.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void displaycostequipment(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7equipmentcost.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }

    @FXML
    private void newlyaddedequipments(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U7Newequipments.fxml"));
                    nextSceneParent = loader.load();
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
                    sameStage.setTitle("Padma Oil Operations");
    }
    
    
   
    
}
