/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

/**
 *
 * @author ragib
 */
public class requestedItem extends item{
    protected int price;
    protected int qty;
    
    public requestedItem()
    {
        
    }
    public requestedItem(int p, int q)
    {
        price=p;
        qty=q;
    }
    public void setItemPrice(int p)
            {
                price=p;
            }
    public int getItemPrice()
            {
                return price;
            }
    public void setItemQty(int q)
            {
                qty=q;
            }
    public int getItemQty()
            {
                return qty;
            }
}
