/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ragib
 */
public class U1ComplainSceneController implements Initializable {

    @FXML
    private TextArea complainArea;
    @FXML
    private TextField complainReasonField;
    @FXML
    private TextField complainIdField;
    @FXML
    private DatePicker complainDate;
    @FXML
    private Label notify;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void u1Home(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                    Parent nextSceneParent;
                    loader.setLocation(getClass().getResource("U1DashboardScene.fxml"));
                    nextSceneParent = loader.load();
                    //U1DashboardSceneController controller = loader.getController();
                    //controller.getUser(empCombobox.getValue()+" Dashboard");
                    Scene nextScene = new Scene(nextSceneParent);
                    Stage sameStage = (Stage)((Node)event.getSource()).getScene().getWindow();       
                    sameStage.setScene(nextScene);
                    sameStage.show();
    }

    @FXML
    private void submitComplaint(ActionEvent event) {
        
        int id=Integer.parseInt(complainIdField.getText());
        String r=complainReasonField.getText();
        String m=complainArea.getText();
        
        
        
        report c = new report(id,r,m);
        
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;
        
        try {
            f = new File("reportObjects.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new customObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            
            oos.writeObject(c);
            
        } catch (IOException ex) {
            Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(oos != null) oos.close();
                notify.setText("Complaint Submitted");
            } catch (IOException ex) {
                Logger.getLogger(U2ManageUsersSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
}
