/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.time.LocalDate;
import java.io.Serializable;
/**
 *
 * @author ragib
 */
public class assignedTask extends task implements Serializable{
    protected int empId;
    protected String empName;
    
    public assignedTask()
    {
        
    }
    /*public assignedTask(int i, int emp)
    {
        taskId=i;
        empId=emp;
    }*/
    public assignedTask(String n, int i, LocalDate s, LocalDate e, int emp)
    {
        tName=n;
        taskId=i;
        sDate=s;
        eDate=e;
        empId=emp;
    }

    public void setEmpId(int e)
    {
        empId=e;
    }
    public int getEmpId()
    {
        return empId;
    }
    public void setEmpName(String n)
    {
        empName=n;
    }
    public String getEmpName()
    {
        return empName;
    }
}
