/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpkg;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author ragib
 */
public class performanceReport extends employee implements Serializable{
    
    protected int att;
    protected int skill;
    protected int behav;
    
    public performanceReport()
    {
        
    }
    public performanceReport(int a, int s, int b,int id, String n, LocalDate birthD, int ph, String e, String pass, LocalDate joinD,String des, int sal)
    {
        //int id, String n, LocalDate birthD, int ph, String e, String pass, LocalDate joinD,String des, int sal
        super(id,n,birthD,ph,e,pass,joinD, des,sal);
        att=a;
        skill=s;
        behav=b;
    }
    public void rateAttendance(int s)
            {
                att=s;
            }
    public int getAttendance()
            {
                return att;
            }
    public void rateSkill(int s)
            {
                skill=s;
            }
    public int getSkill()
            {
                return skill;
            }
    public void rateBehaviour(int s)
            {
                behav=s;
            }
    public int getBehaviour()
            {
                return behav;
            }
    public void submitPerfReport()
    {
        
    }
    
}
